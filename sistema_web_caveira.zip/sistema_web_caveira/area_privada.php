<?php
	session_start();
	if(!isset($_SESSION['id_usuario']))
	{
		header("location: index.php");
		exit;
	}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head> 
	<meta charset="utf-8">
	<title> Nossos serviços...</title>
	<link rel="stylesheet" type="text/css" href="style_area_privada.css">
</head>


<body>
	
	<form class="formulario1" action="">
		<div class="container">
			<div class="container-a">
				<img src="imagem/vitor.jpg">
				<h2>Vitor</h2>
				<p>Meus conteudos</p>
			</div>
		</div>
	</form>

		<!-- <form class="formulario2" action="">
			<div id="container-b"></div>
		</form>

			<form class="formulario3" action="">
				<div id="container-c"></div>
			</form>

				<form class="formulario4" action="">
					<div id="container-d"></div>
				</form>

					<form class="formulario5" action="">
						<div id="container-e"></div>
					</form>

						<form class="formulario6" action="">
							<div id="container-e"></div>
						</form> --> 
</body>
</html>


