<?php
	session_start();
	if(!isset($_SESSION['id_usuario']))
	{
		header("location: index.php");
		exit;
	}
?>


<!DOCTYPE html>
<html lang="pt-br">
<head> 
	<meta charset="utf-8">
	<title> Nossos serviços...</title>
	<link rel="stylesheet" type="text/css" href="style_area_privada.css">
</head>

<body>
	
	<form class="formulario1" action="">
		<div class="container">
			<div class="container-a">
				<img src="imagem/vitor.jpg" widht=100px height=100px>
				<h2>Vitor Meneghetti Peristrello</h2>
				<p>Inicie o curso sem saber de nada (não que hoje eu saiba muita coisa kkkkk) que desde o primeiro dia que inicei minha jornada na Faculdade eu venho aprendendo um pouco a cada dia. </p>
				<br>
				<p>Abaixo deixarei dois Links, um é as minhas principais dificuldades para o desenvolvimento do projeto e o outro é meu perfil no LinkedIn:</p>
				<a href="https://www.linkedin.com/in/vitor-meneghetti-peristrello/" target="_blank">
				<img src="imagem/linkedin.jpg" widht=50px height=50px>
			</div>
		</div>

	</form>


	<form class="formulario1" action="">
		<div class="container"> 
			<div class="container-a">
				<img src="imagem/matheus.jpeg" widht=100px height=100px>
				<h2>Matheus</h2>
				<p>Meus conteudos</p>
			</div>
		</div>
	</form>


	<form class="formulario1" action="">
		<div class="container"> 
			<div class="container-a">
				<img src="imagem/daniel.jpeg" widht=100px height=100px>
				<h2>Daniel</h2>
				<p>Meus conteudos</p>
				<a href="https://www.linkedin.com/in/daniel-oliveira-6446701a9/" target="_blank">
				<img src="imagem/linkedin.jpg" widht=50px height=50px>
			</div>
		</div>
	</form>

	<form class="formulario1" action="">
		<div class="container"> 
			<div class="container-a">
				<img src="imagem/bruno.jpeg" widht=100px height=100px>
				<h2>Bruno</h2>
				<p>Meus conteudos</p>
			</div>
		</div>
	</form>


	<form class="formulario1" action="">
		<div class="container"> 
			<div class="container-a">
				<img src="imagem/danilo.jpeg" widht=100px height=100px>
				<h2>Danilo</h2>
				<p>Meus conteudos</p>
				<h1></h1>
			</div>
		</div>
	</form>


	<form class="formulario1" action="">
		<div class="container"> 
			<div class="container-a">
				<img src="imagem/daniel_u.jpeg" widht=100px height=100px>
				<h2>Daniel Uchoa</h2>
				<p>Meus conteudos</p>
			</div>
		</div>
	</form>

</body>
</html>


